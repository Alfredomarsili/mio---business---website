// Script per gestire la validazione del modulo di contatto
document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault();
    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let message = document.getElementById('message').value;

    if (name && email && message) {
        alert("Messaggio inviato! Ti contatteremo a breve.");
    } else {
        alert("Per favore, compila tutti i campi.");
    }
});
